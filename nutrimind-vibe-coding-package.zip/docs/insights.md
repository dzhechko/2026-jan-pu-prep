# Development Insights — НутриМайнд

A living knowledge base of development learnings. See `.claude/rules/insights-capture.md` for capture guidelines.

---

<!-- Insights will be appended below this line -->
