# Product Discovery Brief: Noom Clone для России
**Дата:** 2026-02-11 | **Режим:** QUICK | **Target:** Россия

---

## MODULE 1: FACT SHEET

### A. КОМПАНИЯ

| Параметр | Значение | Источник | Confidence |
|----------|----------|----------|:----------:|
| Год основания | 2008 | [Crunchbase](https://crunchbase.com/organization/noom) | 5/5 |
| Штаб-квартира | New York, NY, USA | [noom.com](https://noom.com/about-us/) | 5/5 |
| Сотрудники | ~1,185 (на янв 2026; пик ~4,000 в 2022) | [Tracxn](https://tracxn.com/d/companies/noom/) | 4/5 |
| Основатели | Saeju Jeong (CEO), Artem Petakov (President) | Crunchbase | 5/5 |
| Миссия | "Help people everywhere lead healthier lives through behavior change" | noom.com | 5/5 |

### B. ФИНАНСИРОВАНИЕ

| Раунд | Дата | Сумма | Lead Investor | Post-Money |
|-------|------|-------|---------------|:----------:|
| Seed | 2012 | $1.9M | Recruit Strategic Partners | — |
| Series A | 2014 | $7M | Qualcomm Ventures | — |
| Series B | 2017 | $16.4M | Samsung NEXT | — |
| Series C | 2019 | $58M | Sequoia Capital | ~$500M |
| Series F | 2021 | $540M | Silver Lake | **$3.7B** |
| **Итого** | | **~$624M** (14 раундов, 38 инвесторов) | | **$3.7B** |

### C. ПРОДУКТ

| Параметр | Значение | Confidence |
|----------|----------|:----------:|
| Основной продукт | AI-powered weight management через CBT (когнитивно-поведенческую терапию) | 5/5 |
| Платформы | iOS, Android, Web | 5/5 |
| Pricing (Weight) | Free trial → $17-42/мес (12 мес: $209/год, 4 мес: $169) | 5/5 |
| Pricing (Med) | GLP-1 Rx: от $99-129 initial → $199-279/мес | 4/5 |
| Noom Free (сент 2025) | Бесплатный тир с microhabits, Face Scan, Future Me | 5/5 |

**Ключевые фичи (top-5):**
1. CBT-based daily lessons (психология привычек, 5-10 мин/день)
2. AI + human coaching (1-on-1 health coach)
3. Color-coded food tracking (зелёный/жёлтый/оранжевый)
4. Group support communities
5. **Noom Med** — GLP-1 prescriptions + AI glucose forecasting (с сент 2024)

### D. МАСШТАБ И TRACTION

| Метрика | Значение | Дата | Confidence |
|---------|----------|------|:----------:|
| Cumulative signups | 45M+ (downloads 100M+) | 2023-2024 | 4/5 |
| Paying subscribers | ~1.5M | конец 2023 | 3/5 |
| Revenue (ARR) | ~$1B (2023 оценка Sacra); peak $600M (Bloomberg) | 2023 | 3/5 |
| GLP-1 program revenue | $100M run-rate | фев 2025 | 4/5 |
| Women 40-60 years | 8M+ в программе | фев 2025 | 4/5 |
| Key markets | US (primary), UK, Germany, Australia, Japan | | 4/5 |

### E. ТЕХНОЛОГИИ

| Компонент | Технология | Confidence |
|-----------|-----------|:----------:|
| Backend | Python, Java | 3/5 |
| Frontend | React, TypeScript | 3/5 |
| Mobile | React Native + native iOS/Android | 3/5 |
| Cloud | AWS | 3/5 |
| AI/ML | NLP food logging, recommendation engine, CBT personalization, Face Scan, glucose forecasting | 4/5 |
| Data | Snowflake, Kafka | 3/5 |
| Experimentation | 365 A/B tests/year ("Project Meristem") | 4/5 |

---

## MODULE 2: PRODUCT & CUSTOMERS

### A. ONE-LINER

> **Noom** — это Weight Watchers + когнитивно-поведенческая психология через AI-коучинг + GLP-1 медикаменты

### B. PROBLEM STATEMENT

| Измерение | Без Noom | С Noom | Улучшение |
|-----------|---------|--------|-----------|
| **Результат** | 95% диет проваливаются в течение 1 года | 78% пользователей теряют вес | ~10x success rate |
| **Метод** | Calorie counting без понимания "почему" | CBT: понимание триггеров переедания | Устраняет причину, а не симптом |
| **Стоимость** | Диетолог $100-300/сессия | $17-42/мес (digital) | 5-10x дешевле |
| **Доступность** | Очные визиты, ограниченные часы | 24/7, мобильный, AI-driven | Всегда доступен |

### C. 10x IMPROVEMENT

> Noom — первое приложение, которое применяет CBT (когнитивно-поведенческую терапию) к контролю веса в массовом масштабе. Это не просто подсчёт калорий, а изменение поведенческих паттернов. 78% пользователей теряют вес vs 5% при традиционных диетах.

### D. CUSTOMER SEGMENTS (JTBD)

#### Сегмент 1: "Хронический диетчик" — 50% рынка
| Параметр | Описание |
|----------|----------|
| **Кто** | Женщины 30-55 лет, средний доход, городские |
| **Functional Job** | "Помоги мне понять ПОЧЕМУ я переедаю и сломать цикл йо-йо" |
| **Emotional Job** | "Хочу чувствовать контроль, а не вину" |
| **Social Job** | "Хочу выглядеть как человек, заботящийся о себе" |
| **Текущее решение** | MyFitnessPal (бесплатно), Weight Watchers ($20-45/мес) |
| **Триггер** | Фото на событии, визит к врачу, новый год |

#### Сегмент 2: "Осознанный оптимизатор" — 25% рынка
| Параметр | Описание |
|----------|----------|
| **Кто** | 25-45 лет, выше среднего доход, tech-savvy |
| **Functional Job** | "Хочу data-driven подход к здоровью с видимым прогрессом" |
| **Emotional Job** | "Хочу чувствовать себя экспертом своего тела" |
| **Social Job** | "Хочу выглядеть как biohacker, не как больной" |
| **Текущее решение** | Wearables + Lifesum/YAZIO + YouTube |
| **Триггер** | Wearable data показал плохие метрики |

#### Сегмент 3: "GLP-1 curious" — 25% рынка (растущий)
| Параметр | Описание |
|----------|----------|
| **Кто** | 35-60 лет, BMI 30+, готовы платить за результат |
| **Functional Job** | "Хочу медицинскую помощь с похудением без стигмы" |
| **Emotional Job** | "Хочу наконец-то решить проблему раз и навсегда" |
| **Social Job** | "Не хочу, чтобы знали что принимаю препараты" |
| **Текущее решение** | Визит к эндокринологу ($200+/визит), аптечные GLP-1 ($1000+/мес) |
| **Триггер** | Диагноз предиабет, неуспех всех предыдущих методов |

### E. WHY NOW? (4 фактора)

| Фактор | Что произошло | Влияние |
|--------|---------------|---------|
| Технологический | AI/LLM позволяют масштабировать персональный коучинг; Face Scan → biometric screening через камеру | Coaching доступен 24/7 без дорогих специалистов |
| Рыночный | GLP-1 революция (Ozempic, Wegovy) — $50B+ рынок к 2030 | Noom перешёл от lifestyle к medical weight management |
| Поведенческий | Post-COVID: рост wellness-осознанности; 67% взрослых с избыточным весом | Спрос на digital health solutions на историческом максимуме |
| Регуляторный | Telehealth законы расширены; GLP-1 prescriptions online | Можно прописывать препараты через приложение |

### F. ГОЛОС КЛИЕНТА

**Что любят:**
| # | Цитата | Источник |
|---|--------|----------|
| 1 | "Noom helped me understand WHY I eat, not just what" | Reddit |
| 2 | "The psychology lessons changed my relationship with food" | App Store |
| 3 | "Lost 30 lbs in 4 months, kept it off for 2 years" | Trustpilot |

**Что ненавидят:**
| # | Цитата | Источник |
|---|--------|----------|
| 1 | "Billing is a NIGHTMARE — charged after I cancelled" | PissedConsumer (1.5/5 stars) |
| 2 | "Coach feels like a bot, generic answers" | Reddit |
| 3 | "Food database is inaccurate, missing items" | App Store |
| 4 | "$62M lawsuit settlement over billing practices" | BBB/TechCrunch |

**Паттерны:**
- **Positive:** CBT-подход работает, люди меняют отношение к еде (повторяется в 60%+ позитивных отзывов)
- **Negative:** Биллинг/отмена подписки — #1 жалоба; коучинг слишком generic; база продуктов неполная

---

## MODULE 3: MARKET & COMPETITION

### A. TAM / SAM / SOM

**Top-Down:**
| Уровень | Размер | Расчёт |
|---------|--------|--------|
| **TAM** | $87.5B (2026) | Global digital health for obesity market |
| **SAM** | ~$5B | Weight loss apps + digital coaching (software only, без supplements/equipment) |
| **SOM (Россия)** | ~$50-100M | SAM × 2% (Russia share) × digital penetration |

**Bottom-Up (Россия):**
| Параметр | Значение |
|----------|----------|
| Население с избыточным весом | ~50M (63% взрослых) |
| Smartphone penetration | ~85% → 42.5M потенциальных |
| Готовность платить за health app | ~5% → 2.1M |
| × Средний чек | ~500 руб/мес ($6) → **$150M/год** |
| Реалистичная доля за 3 года | 5-10% → **$7.5-15M SOM** |

### B. COMPETITIVE MATRIX

| Параметр | Noom | Weight Watchers | MyFitnessPal | Lifesum | FatSecret | **Наш аналог** |
|----------|:----:|:---------------:|:------------:|:-------:|:---------:|:--------------:|
| Revenue | ~$1B | ~$1.2B | ~$200M | ~$50M | ~$20M | $0 |
| Users | 45M+ | 5M+ | 200M+ | 60M+ | 100M+ | — |
| CBT/Psychology | **Да** | Нет | Нет | Нет | Нет | **Да** |
| AI Coaching | **Да** | Частично | Нет | Нет | Нет | **Да** |
| GLP-1 Rx | **Да** | Частично | Нет | Нет | Нет | Нет (v2) |
| Русский язык | Нет | Нет | Да | Да | Да | **Да** |
| Цена/мес | $17-42 | $13-45 | $0-7 | $0-5 | $0-7 | **$3-10** |

### C. BLUE OCEAN (4 Actions)

| Действие | Что | Почему |
|----------|-----|--------|
| **Eliminate** | Дорогой human coaching ($20+/мес overhead) | AI-коуч на русском языке достаточен для MVP |
| **Reduce** | GLP-1 prescriptions (регуляторные барьеры в РФ) | Фокус на lifestyle, а не медикаменты |
| **Raise** | Локализация: русская база продуктов, местные рецепты, ментальность | Ни один конкурент не сделал CBT на русском |
| **Create** | **CBT + AI коучинг на русском языке** — то чего НЕТ на рынке | Unique value proposition для 50M+ россиян с избыточным весом |

---

## MODULE 4: BUSINESS MODEL (ключевое)

### Revenue Model: Freemium + Subscription

| Tier | Цена | Что включено |
|------|------|-------------|
| Free | $0 | Трекер питания, базовые уроки, microhabits |
| Standard | 499 руб/мес ($6) | CBT-курс, AI-коуч, group support |
| Premium | 999 руб/мес ($12) | + Персональный план, advanced analytics, priority support |

### Unit Economics (план для России)

| Метрика | Noom (US) | Benchmark (Digital Health) | Наш аналог (РФ) |
|---------|-----------|---------------------------|:----------------:|
| **ARPU** | $25-30/мес | $30-80/мес | **$8/мес** |
| **CAC** | $50-100 | $50-150 | **$5-15** |
| **LTV** | $200-400 | $200-600 | **$48-96** (6-12 мес retention) |
| **LTV:CAC** | ~4:1 | 3:1+ | **6-10:1** |
| **Gross Margin** | ~75% | 72%+ | **85%+** (нет human coaches) |
| **Monthly Churn** | ~8% | 5-7% | **10%** (conservative) |
| **Free→Paid Conv** | ~5% | 3-8% | **4%** |

### Break-Even (реалистичный сценарий)

| Параметр | Значение |
|----------|----------|
| Стартовые инвестиции | ~$50-100K (bootstrap/pre-seed) |
| Команда M1 | 3-4 чел (2 dev, 1 product, 1 content) |
| Зарплаты/мес | ~$8-12K |
| Инфра/мес | ~$500-1K |
| Break-even users (paid) | ~2,000 → MRR $16K |
| Break-even month | M9-12 |

---

## MODULE 5: GROWTH ENGINE (ключевое)

### Primary Growth Loop: Content/SEO + Community

```
Step 1: SEO-контент (рус) → органический трафик
    ↓
Step 2: Free tier → microhabits → Aha Moment (день 3-5)
    ↓
Step 3: Conversion → Paid (CBT course unlock)
    ↓
Step 4: Results → Social sharing → Referrals → Step 1
    ↓
Step 5: Data moat → Better AI → Better results → Retention
```

### Top-3 Acquisition Channels

| # | Канал | CAC (ожид.) | Timing |
|---|-------|:-----------:|--------|
| 1 | SEO/Content (рус. блог, YouTube) | $2-5 | M1-6 |
| 2 | Telegram/VK communities + influencers | $5-10 | M3-9 |
| 3 | Paid (VK Ads, Яндекс Директ) | $10-15 | M6-12 |

### Moats (по силе)

| # | Moat | Сила | Время |
|---|------|:----:|:-----:|
| 1 | **Data moat** — CBT personalization на русском (AI) | ●●●●● | 2+ лет |
| 2 | **Content moat** — CBT-контент на русском (400+ уроков) | ●●●● | 1 год |
| 3 | **Network effect** — group support communities | ●●● | 6 мес |
| 4 | **Brand** — "первый CBT для похудения на русском" | ●●● | 6 мес |

---

## ВЫВОДЫ ДЛЯ PRD

### Ключевые инсайты
1. **CBT + AI coaching на русском = пустая ниша**. Ни одно приложение не предлагает психологический подход к питанию на русском языке
2. **Noom's слабости — наши возможности**: биллинг-скандалы, дорогой coaching, нет локализации для РФ
3. **GLP-1 — отложить на v2**: регуляторные барьеры в РФ, начать с lifestyle
4. **Unit economics лучше за счёт**: AI вместо human coaches, низкие зарплаты в РФ, дешёвая acquisition через SEO/Telegram
5. **Рынок есть**: 50M+ россиян с избыточным весом, растущий digital health тренд

### Product Context для Phase 1 (SPARC PRD)
- **Target Segments:** Хронический диетчик (50%), Осознанный оптимизатор (25%), Health-curious (25%)
- **Key Competitors:** MyFitnessPal, Lifesum, FatSecret, YAZIO (ни один не имеет CBT)
- **Differentiation:** CBT psychology + AI coaching на русском языке
- **Monetization:** Freemium → $6-12/мес, target LTV:CAC 6-10:1
- **MVP scope:** Food tracker + CBT lessons (20 уроков) + AI coach + group support

---

**Sources:**
- [Noom Crunchbase](https://crunchbase.com/organization/noom)
- [Sacra: Noom Revenue](https://sacra.com/c/noom/)
- [Tracxn: Noom Profile](https://tracxn.com/d/companies/noom/)
- [Noom Engineering Blog](https://medium.com/noom-engineering)
- [Growth Models: Noom Marketing](https://growthmodels.co/noom-marketing/)
- [Towards Healthcare: Digital Health Market](https://www.towardshealthcare.com/insights/digital-health-for-obesity-market-sizing)
- [ConsumerAffairs: Noom Reviews](https://www.consumeraffairs.com/health/noom.html)
- [PissedConsumer: Noom](https://noom.pissedconsumer.com/review.html)

---

## CHOSEN CJM: Вариант C — 🔍 AI-Детектив

**Зафиксирован:** 2026-02-11

### Параметры выбранного CJM

| Параметр | Значение |
|----------|----------|
| **Aha Moment** | AI находит уникальный паттерн срывов пользователя |
| **Entry Hook** | "Разберись почему ты срываешься" (Emotional Job Seg.1) |
| **Onboarding** | AI-интервью → анализ паттернов (2 вопроса + data collection) |
| **Core Loop** | AI-инсайты + "триггер дня" + предсказание рисков |
| **Paywall** | После 3-го AI-инсайта (proof of value) |
| **Invite** | "Узнай паттерн подруги — парный AI-анализ" |
| **Hypothesis** | AI-персонализация = new moat; proof of value перед paywall |

### Как CJM C влияет на следующие модули

| Модуль | Input из CJM C |
|--------|----------------|
| **PRD (Phase 1)** | MVP = 6 экранов: Landing → AI-интервью → Aha (паттерн найден) → Dashboard (инсайты) → Paywall (после 3 инсайтов) → Invite |
| **Architecture** | AI/ML pipeline для анализа паттернов переедания; real-time risk scoring |
| **Unit Economics** | Paywall после proof of value → ожидаемая конверсия 5-8% (выше avg) |
| **Growth** | Core loop: AI-инсайты каждый день → retention; парный AI-анализ → виральность |
| **Moat** | Data moat: чем больше данных → лучше AI → точнее паттерны → сильнее lock-in |
